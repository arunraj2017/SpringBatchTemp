package com.batch.demo.reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.stereotype.Component;

@Component
public class CustomItemReader implements ItemReader<List<String>> {

	@Override
	public List<String> read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		List<String> items = new ArrayList<>();
		try(BufferedReader br = new BufferedReader(new FileReader("src/main/resources/input.txt"))) {
			String line;
			while((line = br.readLine()) !=null) {
				items.add(line);
			}
		}
		
		return items;
	}
	

}