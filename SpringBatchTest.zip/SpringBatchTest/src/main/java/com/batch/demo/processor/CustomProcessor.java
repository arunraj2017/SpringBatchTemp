package com.batch.demo.processor;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;
@Component
public class CustomProcessor implements ItemProcessor<List<String>, List<String>> {

	@Override
	public List<String> process(List<String> items) throws Exception {
		return items.stream().map(item -> {

			// do splitting and all stuffs here
			System.out.println("--Processing--");
			return item + "E | SUCCESS";
		}).collect(Collectors.toList());
	}

}
