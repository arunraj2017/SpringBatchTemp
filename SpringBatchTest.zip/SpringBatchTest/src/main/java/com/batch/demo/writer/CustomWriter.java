package com.batch.demo.writer;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

@Component
public class CustomWriter implements ItemWriter<List<String>> {

	@Override
	public void write(List<? extends List<String>> items) throws Exception {
	System.out.println(items);
		
	}

	/*
	 * @Override public void write(List<? extends String> items) throws Exception {
	 * 
	 * try(BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt",
	 * true))){ writer.write(items.toString()); } }
	 */

}
