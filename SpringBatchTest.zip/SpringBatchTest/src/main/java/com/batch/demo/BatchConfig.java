package com.batch.demo;

import java.util.List;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.batch.demo.processor.CustomProcessor;
import com.batch.demo.reader.CustomItemReader;
import com.batch.demo.writer.CustomWriter;

@Configuration
@EnableScheduling
@EnableBatchProcessing
public class BatchConfig {
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	@Autowired
	private CustomItemReader reader;
	@Autowired
	private CustomWriter writer;
	@Autowired
	private CustomProcessor processor;
	
	
	 @Bean
	    public Job customerReportJob() {
	        return jobBuilderFactory.get("customerReportJob")
	            .incrementer(new RunIdIncrementer())
	            .start(step1())
	            .build();
	    }
	@Bean
	public Step step1() {
		return stepBuilderFactory
				.get("job")
				.<List<String>, List<String>> chunk(1)
				.reader(this.reader)
				.processor(this.processor)
				.writer(this.writer).build();
				}

}
